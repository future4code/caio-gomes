"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const knex = require("knex");
const Video_1 = require("./../../business/entities/Video");
class VideoDataBase {
    constructor() {
        this.connection = knex({
            client: "mysql",
            connection: {
                host: "ec2-18-208-115-17.compute-1.amazonaws.com",
                user: "caio",
                password: process.env.DB_TOKEN,
                database: "futuretube"
            }
        });
        this.getSQLDateFromTSDate = (date) => date.toISOString().split("T")[0];
    }
    uploadVideo(video) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.connection.raw(`
      INSERT INTO videos (id, title, description, user_id, url)
      VALUES ("${video.getVideoId()}",
      "${video.getTitle()}",
      "${video.getDescription()}",
      "${video.getUserId()}",
      "${video.getUrl()}"
      )
    `);
        });
    }
    getAllVideos() {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this.connection.raw(`
    SELECT * FROM videos
    JOIN users ON user_id = users.id 
    `);
            const videosFromDb = result[0];
            return videosFromDb.map((video) => ({
                video: new Video_1.Video(video.id, video.title, video.description, video.url, video.userId),
                firstName: video.firstName,
                lastName: video.lastName,
                photo: video.photo
            }));
        });
    }
    getUserVideos(userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this.connection.raw(`
    SELECT * FROM videos
    JOIN users ON user_id = users.id 
    WHERE user_id = "${userId}";
    `);
            const videoFromDb = result[0];
            return videoFromDb.map((video) => ({
                video: new Video_1.Video(video.id, video.title, video.description, video.url, video.userId),
                firstName: video.firstName,
                lastName: video.lastName,
                photo: video.photo
            }));
        });
    }
    deleteVideo(videoId) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.connection.raw(`DELETE FROM videos WHERE id = "${videoId}"`);
        });
    }
    editVideoInformation(videoId, newTitle, newDescription) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.connection.raw(`
    UPDATE videos
    SET title = "${newTitle}", description = "${newDescription}"
    WHERE id = "${videoId}";
    `);
        });
    }
}
exports.VideoDataBase = VideoDataBase;
