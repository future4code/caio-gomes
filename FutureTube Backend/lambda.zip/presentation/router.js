"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const changePassword_1 = require("./../business/usecases/User/changePassword");
const login_1 = require("./../business/usecases/User/login");
const signup_1 = require("../business/usecases/User/signup");
const userDatabase_1 = require("../data/User/userDatabase");
const jwtAuthentication_1 = require("../services/Auth/jwtAuthentication");
const bcrypt_1 = require("../services/Cryptography/bcrypt");
const v4IdGenerator_1 = require("../services/Auth/v4IdGenerator");
const uploadVideoUC_1 = require("../business/usecases/Video/uploadVideoUC");
const videoDatabase_1 = require("../data/Videos/videoDatabase");
const getAllVideosUC_1 = require("../business/usecases/Video/getAllVideosUC");
const deleteVideoUC_1 = require("../business/usecases/Video/deleteVideoUC");
const editVideoInformation_1 = require("../business/usecases/Video/editVideoInformation");
const getVideoInformationUC_1 = require("../business/usecases/Video/getVideoInformationUC");
class ApiRouter {
    static handleRoute(path, event) {
        return __awaiter(this, void 0, void 0, function* () {
            switch (path) {
                case "createUser":
                    const signup = new signup_1.SignupUC(new userDatabase_1.UserDataBase(), new jwtAuthentication_1.JwtAuthService(), new bcrypt_1.BcryptService(), new v4IdGenerator_1.V4IdGenerator());
                    const { firstName, lastName, email, birthday, photo, password } = event.body;
                    const resultSignup = yield signup.execute({
                        firstName,
                        lastName,
                        email,
                        birthday,
                        photo,
                        password
                    });
                    return resultSignup;
                case "login":
                    const loginUC = new login_1.LoginUC(new userDatabase_1.UserDataBase(), new jwtAuthentication_1.JwtAuthService(), new bcrypt_1.BcryptService());
                    const resultLogin = yield loginUC.execute(event.body.email, event.body.password);
                    return resultLogin;
                case "changePassword":
                    const changePasswordUC = new changePassword_1.ChangeUserPasswordUC(new jwtAuthentication_1.JwtAuthService(), new userDatabase_1.UserDataBase(), new bcrypt_1.BcryptService(), new userDatabase_1.UserDataBase());
                    const resultChangePassword = yield changePasswordUC.execute({
                        token: this.getTokenFromHeaders(event.headers),
                        oldPassword: event.body.oldPassword,
                        newPassword: event.body.newPassword
                    });
                    return resultChangePassword;
                case "uploadVideo":
                    const authService = new jwtAuthentication_1.JwtAuthService();
                    const userId = authService.getUserIdFromToken(this.getTokenFromHeaders(event.headers));
                    const uploadVideo = new uploadVideoUC_1.UploadVideoUC(new videoDatabase_1.VideoDataBase(), new v4IdGenerator_1.V4IdGenerator());
                    const input = {
                        title: event.body.title,
                        description: event.body.description,
                        url: event.body.url,
                        userId
                    };
                    const resultUploadVideo = yield uploadVideo.execute(input);
                    return resultUploadVideo;
                case "allVideos":
                    const getAllVideos = new getAllVideosUC_1.GetAllVideosUC(new videoDatabase_1.VideoDataBase());
                    const resultGetAllVideos = yield getAllVideos.execute();
                    return resultGetAllVideos;
                case "deleteVideo":
                    const deleteVideo = new deleteVideoUC_1.DeleteVideoUC(new videoDatabase_1.VideoDataBase());
                    const inputDeleteVideo = {
                        videoId: event.body.videoId
                    };
                    const resultDeleteVideo = yield deleteVideo.execute(inputDeleteVideo);
                    return resultDeleteVideo;
                case "edit/video":
                    const editVideo = new editVideoInformation_1.EditVideoInformationUC(new videoDatabase_1.VideoDataBase());
                    const inputEditVideo = {
                        videoId: event.body.videoId,
                        newTitle: event.body.newTitle,
                        newDescription: event.body.newDescription
                    };
                    const resultEditVideo = yield editVideo.execute(inputEditVideo);
                    return resultEditVideo;
                case "video/information":
                    const useCase = new getVideoInformationUC_1.GetVideoInformationUC(new videoDatabase_1.VideoDataBase());
                    const inputVideoInformation = {
                        videoId: event.body.videoId
                    };
                    const resultVideoInformation = yield useCase.execute(inputVideoInformation);
                    return resultVideoInformation;
                default:
                    throw new Error("Rota não existe");
            }
        });
    }
}
exports.ApiRouter = ApiRouter;
ApiRouter.getTokenFromHeaders = (headers) => {
    return headers["auth"] || "";
};
