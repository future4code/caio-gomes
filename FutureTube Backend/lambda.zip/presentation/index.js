"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const getVideoInformationUC_1 = require("./../business/usecases/Video/getVideoInformationUC");
const deleteVideoUC_1 = require("./../business/usecases/Video/deleteVideoUC");
const getAllVideosUC_1 = require("./../business/usecases/Video/getAllVideosUC");
const videoDatabase_1 = require("./../data/Videos/videoDatabase");
const uploadVideoUC_1 = require("./../business/usecases/Video/uploadVideoUC");
const express_1 = __importDefault(require("express"));
const signup_1 = require("../business/usecases/User/signup");
const userDatabase_1 = require("../data/User/userDatabase");
const jwtAuthentication_1 = require("../services/Auth/jwtAuthentication");
const bcrypt_1 = require("../services/Cryptography/bcrypt");
const v4IdGenerator_1 = require("../services/Auth/v4IdGenerator");
const login_1 = require("../business/usecases/User/login");
const changePassword_1 = require("../business/usecases/User/changePassword");
const editVideoInformation_1 = require("../business/usecases/Video/editVideoInformation");
const app = express_1.default();
app.use(express_1.default.json()); // Linha mágica (middleware)
exports.default = app;
const getTokenFromHeaders = (headers) => {
    return headers["auth"] || "";
};
app.post("/createUser", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const signup = new signup_1.SignupUC(new userDatabase_1.UserDataBase(), new jwtAuthentication_1.JwtAuthService(), new bcrypt_1.BcryptService(), new v4IdGenerator_1.V4IdGenerator());
        const result = yield signup.execute({
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email,
            birthday: req.body.birthday,
            photo: req.body.photo,
            password: req.body.password
        });
        res.status(200).send(result);
    }
    catch (err) {
        res.status(404).send(Object.assign(Object.assign({}, err), { errorMessage: err.message }));
    }
}));
app.post("/login", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const login = new login_1.LoginUC(new userDatabase_1.UserDataBase(), new jwtAuthentication_1.JwtAuthService(), new bcrypt_1.BcryptService());
        const result = yield login.execute(req.body.email, req.body.password);
        res.status(200).send(result);
    }
    catch (err) {
        res.status(400).send(Object.assign(Object.assign({}, err), { errorMessage: err.message }));
    }
}));
app.post("/changePassword", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const changePasswordUC = new changePassword_1.ChangeUserPasswordUC(new jwtAuthentication_1.JwtAuthService(), new userDatabase_1.UserDataBase(), new bcrypt_1.BcryptService(), new userDatabase_1.UserDataBase());
        const result = yield changePasswordUC.execute({
            token: getTokenFromHeaders(req.headers),
            oldPassword: req.body.oldPassword,
            newPassword: req.body.newPassword
        });
        res.status(200).send(result);
    }
    catch (err) {
        res.status(400).send({
            errorMessage: err.message
        });
    }
}));
app.post("/uploadVideo", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const authService = new jwtAuthentication_1.JwtAuthService();
        const userId = authService.getUserIdFromToken(getTokenFromHeaders(req.headers));
        const uploadVideo = new uploadVideoUC_1.UploadVideoUC(new videoDatabase_1.VideoDataBase(), new v4IdGenerator_1.V4IdGenerator());
        const input = {
            title: req.body.title,
            description: req.body.description,
            url: req.body.url,
            userId
        };
        const result = yield uploadVideo.execute(input);
        res.status(200).send(result);
    }
    catch (err) {
        res.status(400).send({
            errorMessage: err.message
        });
    }
}));
app.get("/allVideos", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const getAllVideos = new getAllVideosUC_1.GetAllVideosUC(new videoDatabase_1.VideoDataBase());
        const result = yield getAllVideos.execute();
        res.status(200).send(result);
    }
    catch (err) {
        res.status(400).send({
            errorMessage: err.message
        });
    }
}));
app.delete("/video", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const deleteVideo = new deleteVideoUC_1.DeleteVideoUC(new videoDatabase_1.VideoDataBase());
        const input = {
            videoId: req.body.videoId
        };
        const result = yield deleteVideo.execute(input);
        res.status(200).send(result);
    }
    catch (err) {
        res.status(400).send({
            errorMessage: err.message
        });
    }
}));
app.put("/edit/video", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const editVideo = new editVideoInformation_1.EditVideoInformationUC(new videoDatabase_1.VideoDataBase());
        const input = {
            videoId: req.body.videoId,
            newTitle: req.body.newTitle,
            newDescription: req.body.newDescription
        };
        const result = yield editVideo.execute(input);
        res.status(200).send(result);
    }
    catch (err) {
        res.status(400).send({
            errorMessage: err.message
        });
    }
}));
app.get("/video/information", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const useCase = new getVideoInformationUC_1.GetVideoInformationUC(new videoDatabase_1.VideoDataBase());
        const input = {
            videoId: req.body.videoId
        };
        const result = yield useCase.execute(input);
        res.status(200).send(result);
    }
    catch (err) {
        res.status(400).send({
            errorMessage: err.message
        });
    }
}));
