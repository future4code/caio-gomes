"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
class GetAllVideosUC {
    constructor(getAllVideosGateway) {
        this.getAllVideosGateway = getAllVideosGateway;
    }
    execute() {
        return __awaiter(this, void 0, void 0, function* () {
            const responses = yield this.getAllVideosGateway.getAllVideos();
            return {
                videos: responses.map(response => ({
                    title: response.video.getTitle(),
                    description: response.video.getDescription(),
                    url: response.video.getUrl(),
                    userId: response.video.getUserId(),
                    firstName: response.firstName,
                    lastName: response.lastName,
                    photo: response.photo
                }))
            };
        });
    }
}
exports.GetAllVideosUC = GetAllVideosUC;
