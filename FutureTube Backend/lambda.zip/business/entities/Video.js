"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Video {
    constructor(videoId, title, description, url, userId) {
        this.videoId = videoId;
        this.title = title;
        this.description = description;
        this.url = url;
        this.userId = userId;
    }
    getVideoId() {
        return this.videoId;
    }
    getTitle() {
        return this.title;
    }
    getDescription() {
        return this.description;
    }
    getUrl() {
        return this.url;
    }
    getUserId() {
        return this.userId;
    }
}
exports.Video = Video;
