"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class User {
    constructor(id, firstName, lastName, email, birthday, photo, password) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.birthday = birthday;
        this.photo = photo;
        this.password = password;
    }
    getId() {
        return this.id;
    }
    getFirstName() {
        return this.firstName;
    }
    getLastName() {
        return this.lastName;
    }
    getEmail() {
        return this.email;
    }
    getBirthday() {
        return this.birthday;
    }
    getPhoto() {
        return this.photo;
    }
    getPassword() {
        return this.password;
    }
}
exports.User = User;
